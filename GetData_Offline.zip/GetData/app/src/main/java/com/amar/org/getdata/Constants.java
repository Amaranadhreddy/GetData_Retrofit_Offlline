package com.amar.org.getdata;

/**
 * Created by govt on 21-10-2017.
 */

public class Constants {

    public static final String BASE_URL = "https://api.androidhive.info/";
}
