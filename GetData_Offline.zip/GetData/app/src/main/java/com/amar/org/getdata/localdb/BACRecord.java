package com.amar.org.getdata.localdb;

import java.io.Serializable;

public class BACRecord implements Serializable {

    String id;
    String indexID, name, price, description;
    String thumbnail;

    public BACRecord() {

    }

    public BACRecord(String id, String indexID, String name, String price, String description, String thumbnail) {
        this.id = id;
        this.indexID = indexID;
        this.name = name;
        this.price = price;
        this.description = description;
        this.thumbnail = thumbnail;
    }

    public BACRecord(String id, String name, String price, String description, String thumbnail) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.description = description;
        this.thumbnail = thumbnail;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIndexID() {
        return indexID;
    }

    public void setIndexID(String indexID) {
        this.indexID = indexID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }
}
