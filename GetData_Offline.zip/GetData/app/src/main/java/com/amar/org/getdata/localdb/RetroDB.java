package com.amar.org.getdata.localdb;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.amar.org.getdata.Menu;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by prasannapulagam on 2/22/18.
 */

public class RetroDB extends SQLiteOpenHelper {

    // Database Version
    private static final int DATABASE_VERSION = 1;
    // Database Name
    private static final String DATABASE_NAME = "CheckBACDatabase";
    // Temples table name
    private static final String CHECHBAC_RESULT_TABLE = "CheckBACResultTable";
    private static final String KEY_ID = "id";
    private static final String ID = "id_name";
    private static final String NAME = "name";
    private static final String PRICE = "price";
    private static final String DESCRIPTION = "description";
    private static final String THUMBNAIL = "thumbnail";

    public RetroDB(Context applicationContext) {
        super(applicationContext, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //Create Table for BACtrack Result
        String CREATE_CHECHBAC_RESULT_TABLE = "CREATE TABLE " + CHECHBAC_RESULT_TABLE + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + ID + " TEXT,"
                + NAME + " TEXT,"
                + PRICE + " TEXT,"
                + DESCRIPTION + " TEXT,"
                + THUMBNAIL + " TEXT " + ")";
        db.execSQL(CREATE_CHECHBAC_RESULT_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + CHECHBAC_RESULT_TABLE);
    }

    //add the CheckBAC Active list
    public void addChecBACResultList(Menu bacResultRecord) {
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_ID, bacResultRecord.getIndexID());
        values.put(ID, bacResultRecord.getId());
        values.put(NAME, bacResultRecord.getName());
        values.put(PRICE, bacResultRecord.getPrice());
        values.put(DESCRIPTION, bacResultRecord.getDesctiption());
        values.put(THUMBNAIL, bacResultRecord.getThumbnail());
        //Inserting Row
        long result = database.insert(CHECHBAC_RESULT_TABLE, null, values);
        //close the local database
        database.close();

    }

    //get the list
    public List<Menu> getAllBACResultList() {
        List<Menu> bacRecordList = new ArrayList<>();
        try {
            //Select Query
            String query = "SELECT * FROM " + CHECHBAC_RESULT_TABLE;
            SQLiteDatabase database = this.getWritableDatabase();
            Cursor cursor = database.rawQuery(query, null);
            if (cursor.moveToFirst()) {
                do {
                    Menu bacResultRecord = new Menu();
                    bacResultRecord.setIndexID(cursor.getString(0));
                    bacResultRecord.setId(cursor.getString(1));
                    bacResultRecord.setName(cursor.getString(2));
                    bacResultRecord.setPrice(cursor.getString(3));
                    bacResultRecord.setDesctiption(cursor.getString(4));
                    bacResultRecord.setThumbnail(cursor.getString(5));
                    bacRecordList.add(bacResultRecord);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bacRecordList;
    }

    //remove the local database list
    public void removeBACResultList() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + CHECHBAC_RESULT_TABLE);
        //close the local database
        db.close();
    }

    public int updateRecord(BACRecord bacResultRecord) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_ID, bacResultRecord.getIndexID());
        values.put(ID, bacResultRecord.getId());
        values.put(NAME, bacResultRecord.getName());
        values.put(PRICE, bacResultRecord.getPrice());
        values.put(DESCRIPTION, bacResultRecord.getDescription());
        values.put(THUMBNAIL, bacResultRecord.getThumbnail());
        return db.update(CHECHBAC_RESULT_TABLE, values, KEY_ID + "=?", new String[]{String.valueOf(bacResultRecord.getIndexID())});
    }
}


