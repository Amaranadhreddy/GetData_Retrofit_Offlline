package com.amar.org.getdata;

import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.amar.org.getdata.localdb.BACRecord;
import com.amar.org.getdata.localdb.RetroDB;
import com.amar.org.getdata.network.ConnectionDetector;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;
import static android.Manifest.permission.CAMERA;
import static android.Manifest.permission.READ_CONTACTS;
import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.READ_PHONE_STATE;
import static android.Manifest.permission.RECORD_AUDIO;
import static android.Manifest.permission.SEND_SMS;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

public class MainActivity extends AppCompatActivity {

    private ProgressDialog progressDialog;
    private DataAdapter dataAdapter;
    private List<Menu> menuList;
    private RecyclerView recyclerView;

    private RetroDB RETRODB;
    List<Menu> bacResultRecordsList;
    private List<Menu> notificationList = new ArrayList<>();
    Boolean isInternetPresent = false;
    ConnectionDetector connectionDetector;
    private static final int PERMISSION_REQUEST_CODE = 200;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RETRODB = new RetroDB(MainActivity.this);
        menuList = new ArrayList<>();
        recyclerView = (RecyclerView)findViewById(R.id.card_recycler_view);
        recyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        connectionDetector = new ConnectionDetector(MainActivity.this);
        isInternetPresent = connectionDetector.isConnectingToInternet();
        bacResultRecordsList = RETRODB.getAllBACResultList();



        if (isInternetPresent) {
            getMenu();
        } else {
            getLocalRecords();
        }
    }

    private void getLocalRecords() {
        if (bacResultRecordsList.size() > 0) {
            for (int i = 0; i < bacResultRecordsList.size(); i++) {
                notificationList.add(new Menu(bacResultRecordsList.get(i).getId(),
                        bacResultRecordsList.get(i).getName(),
                        bacResultRecordsList.get(i).getPrice(), bacResultRecordsList.get(i).getDesctiption(),
                        bacResultRecordsList.get(i).getThumbnail()));
            }
            dataAdapter = new DataAdapter(MainActivity.this, notificationList);
            RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(MainActivity.this);
            recyclerView.setLayoutManager(mLayoutManager);
            recyclerView.setItemAnimator(new DefaultItemAnimator());
            recyclerView.setAdapter(dataAdapter);
            recyclerView.setHasFixedSize(true);
            dataAdapter.notifyDataSetChanged();
        } else {
            Toast.makeText(MainActivity.this, "Data is not found.", Toast.LENGTH_SHORT).show();
        }

    }

    private void getMenu() {

        showProgressDialog();

        MenuApiClient.getApiService().getMenu().enqueue(new Callback<List<Menu>>() {
            @Override
            public void onResponse(Call<List<Menu>> call, Response<List<Menu>> response) {
                dismissProgressDialog();

                if (response.isSuccessful()){
                    menuList = response.body();
                   ArrayList<Menu> dataList = new ArrayList<Menu>();

                    RETRODB.removeBACResultList();

                    for (int i = 0; i < menuList.size(); i++){

                        RETRODB.addChecBACResultList(new Menu(menuList.get(i).getId(),menuList.get(i).getName(),
                                menuList.get(i).getPrice(), menuList.get(i).getDesctiption(),
                                menuList.get(i).getThumbnail()));

                        notificationList.add(new Menu(menuList.get(i).getId(),menuList.get(i).getName(),
                                menuList.get(i).getPrice(), menuList.get(i).getDesctiption(),
                                menuList.get(i).getThumbnail()));


                        dataAdapter = new DataAdapter(MainActivity.this, notificationList);
                        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(MainActivity.this);
                        recyclerView.setLayoutManager(mLayoutManager);
                        recyclerView.setItemAnimator(new DefaultItemAnimator());
                        recyclerView.setAdapter(dataAdapter);
                        recyclerView.setHasFixedSize(true);
                        dataAdapter.notifyDataSetChanged();
                    }
                }
            }

            @Override
            public void onFailure(Call<List<Menu>> call, Throwable t) {
                dismissProgressDialog();
                Toast.makeText(MainActivity.this, "Something went wrong, pls try again!", Toast.LENGTH_SHORT).show();
            }
        });
    }


    public void showProgressDialog() {
        progressDialog = new ProgressDialog(MainActivity.this);
        progressDialog.setMessage("Processing");
        progressDialog.setCancelable(false);
        progressDialog.show();

    }

    public void dismissProgressDialog() {
        if (progressDialog != null) {
            if (progressDialog.isShowing()) {
                progressDialog.dismiss();
            }
        }

    }

}
